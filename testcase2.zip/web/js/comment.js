var isValid = true; //правильно ли заполнена форма

//после загрузки html отправляем запрос на сервер для получения списка регионов
document.addEventListener("DOMContentLoaded", function(event){
	var request = new XMLHttpRequest();
	request.open('POST', '/comment/');
	request.addEventListener('readystatechange', function(){
		if (this.readyState != 4){
			return;
		}
		
		if (this.status === 200) {
			var region_select = document.forms['comment_form']['region'];
			var region_list = JSON.parse(this.responseText);
			for (var i in region_list){
				region_select.add(new Option(region_list[i].region_name,region_list[i].region_id));
			}
		} else {
				alert("Произошла ошибка при загрузке списка регионов");
		}
	});
	request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
	request.send('action=get_regions');
});

//проверяем правильно ли заполнена форма
function check_form() {
	isValid = true;
	var phone_regex = /^\(\d+\)\d+$/;
	var email_regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w+)+$/;
	//проверка полей
	check_field(document.forms['comment_form']['last_name']);
	check_field(document.forms['comment_form']['name']);
	check_field(document.forms['comment_form']['comment_text']);
	check_field(document.forms['comment_form']['phone'], phone_regex);
	check_field(document.forms['comment_form']['email'], email_regex);
	if (isValid === true){
		send_form(document.forms['comment_form']);
	}
	return false;
}

function check_field(field, regex){
	//если поле не заполнено, но является обязательным к заполнению (regex = undefined) или заполнено, но неверно, то выделяем поле
	if ((regex === undefined && field.value.trim().length === 0) || (regex != undefined && field.value.length != 0 && !regex.exec(field.value))){
		field.setCustomValidity('Пожалуйста, заполните это поле.');
		if (isValid === true) {
			isValid = false;
		}
	} else {
		field.setCustomValidity('');
	}
}

//получаем список городов
function get_cities(region_id){
	var city_select = document.forms['comment_form']['city'];
	city_select.innerHTML = '';
	if (region_id != 0){
		var request = new XMLHttpRequest();
		request.open('POST', '/comment/');
		request.addEventListener('readystatechange', function(){
			if (this.readyState != 4){
				return;
			}
			
			if (this.status === 200) {
				var city_list = JSON.parse(this.responseText);
				for (var i in city_list){
					city_select.add(new Option(city_list[i].city_name,city_list[i].city_id));
				}
				city_select.disabled = false;
			} else {
				alert("Произошла ошибка при загрузке списка городов");
			}
		});
		request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
		request.send('action=get_cities&region_id=' + region_id);
	}
	else {
		city_select.disabled = true;
	}
}

//отправляем форму
function send_form(formData){
	var request_query = 'action=send_form&last_name='+formData['last_name'].value
	+'&name='+formData['name'].value
	+'&middle_name='+formData['middle_name'].value
	+'&city='+formData['city'].value
	+'&phone='+formData['phone'].value
	+'&email='+formData['email'].value
	+'&comment_text='+formData['comment_text'].value;
	var request = new XMLHttpRequest();
	request.open('POST', '/comment/');
	request.addEventListener('readystatechange', function(){
		if (this.readyState != 4){
			return;
		}
		
		document.getElementById('comment_form').innerHTML = '';
		var p = document.createElement('p');
		if (this.status === 200 && JSON.parse(this.responseText) === 'ok') {
			p.innerHTML = 'Комментарий добавлен';
		} else {
			p.innerHTML = 'Произошла ошибка при добавлении комментария';
		}
		document.getElementById('comment_form').appendChild(p);
	});
	request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
	request.send(request_query);
}
