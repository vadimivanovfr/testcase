document.addEventListener('DOMContentLoaded', get_comments);

//загружаем список комментариев
function get_comments(){
	var comment_table = document.getElementById('comment_table');
	comment_table.innerHTML = '';
	var request = new XMLHttpRequest();
	request.open('POST', '/view/');
	request.addEventListener('readystatechange', function(){
		if (this.readyState != 4){
			return;
		}
		
		if (this.status === 200) {
			var stat_list = JSON.parse(this.responseText);
			var header_row = comment_table.createTHead().insertRow();
			header_row.insertCell().innerHTML = 'Комментарий';
			header_row.insertCell();
			var comment = JSON.parse(this.responseText);
			for (var i in comment){
				var row = comment_table.insertRow()
				row.insertCell().innerHTML = comment[i].comment_text;
				row.insertCell().innerHTML = '<a href="#" onclick="delete_comment('+comment[i].comment_id+'); return false;">Удалить</a>';
			}
		} else {
				alert('Произошла ошибка при загрузке списка комментариев');
		}
	});
	request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
	request.send('action=get_comments');
}

//посылаем запрос на удаление комментария и обновляем список
function delete_comment(comment_id){
	var request = new XMLHttpRequest();
	request.open('POST', '/view/');
	request.addEventListener('readystatechange', function(){
		if (this.readyState != 4){
			return;
		}
		
		if (this.status === 200) {
			get_comments();
		} else {
				alert('Произошла ошибка при удалении комментария');
		}
	});
	request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
	request.send('action=delete_comment&comment_id='+comment_id);
}