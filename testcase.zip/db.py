import config
import psycopg2
import psycopg2.extras
import re

#обращения к БД
class QueryExec:
	error_num = None
	def __init__(self, query, params=()):
		try:
			self.conn = psycopg2.connect(**config.db)
			self.cur = self.conn.cursor(cursor_factory = psycopg2.extras.RealDictCursor)
			self.cur.execute(query, params)
		except (Exception, psycopg2.DatabaseError) as error:
			print(error)
	
	#получение результатов
	def get_results(self):
		try:
			result = self.cur.fetchall()
			self.close()
			return result
		except (Exception, psycopg2.DatabaseError) as error:
			print(error)
		
	def commit(self):
		self.conn.commit()
		self.close()
		return True
		
	def close(self):
		self.cur.close()
		self.conn.close()

def get_regions():
	return QueryExec('select region_id, region_name from region order by region_name').get_results()

def get_cities(region_id):
	return QueryExec('select city_id, city_name from city where region_id = %s order by city_name', (region_id,)).get_results()
		
def get_comments():
	return QueryExec('''select com.last_name, com.name, c.city_name, com.comment_text, com.comment_id from comment com 
					left join city c on com.city_id = c.city_id 
					order by comment_id''').get_results()

def add_comment(last_name, name, middle_name, city, phone, email, comment_text):
	result = False
	if all([last_name,name,comment_text]): #если обязательные поля заполнены
		result = QueryExec('insert into comment(last_name, name, middle_name, city_id, phone_number, email, comment_text) values (%s,%s,%s,%s,%s,%s,%s)', 
		(last_name, name, middle_name, city, phone, email, comment_text)).commit()
	return result
	
def delete_comment(comment_id):
	return QueryExec('delete from comment where comment_id = %s', (comment_id,)).commit()
		
def get_stat(region_id=None):
	if region_id == None: #если id региона не задан, то выводим статистику по регионам, иначе по городам
		query = '''select r.region_id as region_id, r.region_name as region_name, count(com.comment_id) as cnt from comment com
				left join city c on com.city_id = c.city_id
				left join region r on c.region_id = r.region_id
				group by r.region_id, r.region_name having count(com.comment_id) > 5 order by 3'''
	else:
		if region_id == 'None': #при добавлении комментария регион может быть не указан, тогда region_id is null
			condition = 'where r.region_id is null'
		else:
			condition = 'where r.region_id = %s'
		query = '''select r.region_name as region_name, c.city_name as city_name, count(com.comment_id) as cnt from comment com
				left join city c on com.city_id = c.city_id
				left join region r on c.region_id = r.region_id 
				{condition}
				group by r.region_name, c.city_name order by 3'''.format(condition=condition)
	return QueryExec(query, (region_id,)).get_results()
