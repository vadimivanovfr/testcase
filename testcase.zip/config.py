project_dir = '/home/testcase/web' #папка с проектом
encoding = 'utf-8' #кодировка
db = { #данные БД
'host': 'localhost',
'database': 'testcase',
'user': 'postgres',
'password': ''
}