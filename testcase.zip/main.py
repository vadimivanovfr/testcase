from http.server import HTTPServer, BaseHTTPRequestHandler
import config
import re
import db
from urllib import parse
import json

class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):
	#маршруты: regex - относительный путь; method - метод, который будет вызван для обработки;
	#template - шаблон (html - страница)
	routes = [
		{'regex': '^/comment/(\?)*', 'method': 'comment', 'template': '/comment.html'},
		{'regex': '^/view/(\?)*', 'method': 'view', 'template': '/view.html'},
		{'regex': '^/stat/(\?)*', 'method': 'stat', 'template': '/stat.html'},
		{'regex': '^/js/'},
		{'regex': '^/css/'},
		{'regex': '^/favicon.ico'}
	]
	params = None #параметры запроса
	
	#отправляем ответ клиенту
	def send_resp(self, content, content_type='text/html'):
		self.send_response(200)
		self.send_header('Content-type', content_type)
		self.end_headers()
		if isinstance(content, str): #если ответ сформирован в виде строки, то преобразуем в bytearray
			content = bytearray(content, config.encoding)
		self.wfile.write(content)
	
	#Обработка get, post запросов
	def do_GET(self):
		self.request_handler()
		
	def do_POST(self):
		self.request_handler()
		
	def request_handler(self):
		for route in self.routes:
			if re.match(route['regex'], self.path): #если по относительному пути маршрут найден
				#записываем параметры запроса в params
				if self.command == 'POST':
					query_string = self.rfile.read(int(self.headers['Content-Length']) if int(self.headers['Content-Length']) > 0 else 0).decode()
					self.params = parse.parse_qs(query_string)
				elif self.command == 'GET':
					self.params = parse.parse_qs(parse.urlparse(self.path).query)
				if 'template' in route: #если для маршрута задан шаблон (html файл), то пытаемся открыть его
					try:
						with open(config.project_dir + route['template'], 'r') as f:
							self.content = f.read()
					except IOError:
						self.send_error(404, 'not found')
						return
				else: #если шаблон не задан, то пытаемся открыть файл указанный в относительном пути
					try:
						with open(config.project_dir + self.path, 'rb') as f:
							if self.path.endswith('.css'):
								content_type = 'text/css'
							elif self.path.endswith('.js'):
								content_type = 'application/javascript'
							elif self.path.endswith('.ico'):
								content_type = 'image/x-icon'
							elif self.path.endswith('.zip'):
								content_type = 'application/zip'
							else:
								content_type = 'text/html'
							self.send_resp(f.read(), content_type)
					except IOError:
						self.send_error(404, 'not found')
					finally:
						return
				method = globals()['SimpleHTTPRequestHandler'].__dict__[route['method']] #находим метод, указанный в маршрутах
				if self.params != {}: #если запрос пришёл с параметрами, то вызываем метод обработки, иначе возвращаем страницу шаблона
					method(self)
					return
				else:
					self.send_resp(self.content)
					return
		self.send_error(404, 'not found') #если относительный путь не внесен в список возможных маршрутов, то вывести 404
	
	def comment(self):
		#в зависимости от параметров формируем результат
		if self.has_params(['action']) and self.get_param_value('action') == 'get_regions':
			result = db.get_regions()
		elif self.has_params(['action', 'region_id']) and self.get_param_value('action') == 'get_cities':
			result = db.get_cities(self.get_param_value('region_id'))
		elif self.has_params(['action', 'last_name', 'name', 'comment_text']) and self.get_param_value('action') == 'send_form':
			res = db.add_comment(self.get_param_value('last_name'), 
			self.get_param_value('name'), 
			self.get_param_value('middle_name'),
			self.get_param_value('city'),
			self.get_param_value('phone'),
			self.get_param_value('email'),
			self.get_param_value('comment_text'))
			if res == True:
				result = 'ok'
			else:
				result = 'error'
		else:
			self.send_error(400, 'Bad Request') #если задан другой набор параметров, то ошибка 400
		if result == None:
			self.send_error(500, 'Internal Server Error') #если не смогли сформировать результат, то ошибка 500
		else:
			self.send_resp(json.dumps(result)) #в остальных случаях возвращаем результат
		
	def view(self):
		if self.has_params(['action', 'comment_id']) and self.get_param_value('action') == 'delete_comment':
			result = db.delete_comment(self.get_param_value('comment_id'))
		elif self.has_params(['action']) and self.get_param_value('action') == 'get_comments':
			result = db.get_comments()
		else:
			self.send_error(400, 'Bad Request')
		if result == False or result == None:
			self.send_error(500, 'Internal Server Error')
		else:
			self.send_resp(json.dumps(result))
		
	def stat(self):
		if self.has_params(['action']) and self.get_param_value('action') == 'get_region_stat':
			result = db.get_stat()
		elif self.has_params(['action', 'region_id']) and self.get_param_value('action') == 'get_city_stat':
			result = db.get_stat(self.get_param_value('region_id'))
		else:
			self.send_error(400, 'Bad Request')
		if result == None:
			self.send_error(500, 'Internal Server Error')
		else:
			self.send_resp(json.dumps(result))
	
	#проверка наличия параметров 
	def has_params(self, param_list):
		if all(param in self.params for param in (param_list)):
			return True
		return False
	
	#получение значения параметра
	def get_param_value(self, param):
		if param in self.params:
			return self.params[param][0]
		return None

httpd = HTTPServer(('0.0.0.0', 80), SimpleHTTPRequestHandler)
httpd.serve_forever() #запуск web сервера