//загружаем количество комментариев по регионам
document.addEventListener('DOMContentLoaded', function(event) { 
	var stat_table = document.getElementById('stat_table');
	var request = new XMLHttpRequest();
	request.open('POST', '/stat/');
	request.addEventListener('readystatechange', function(){
		if (this.readyState != 4){
			return;
		}
		
		if (this.status === 200) {
			var stat_list = JSON.parse(this.responseText);
			//stat_table.createCaption('Статистика по регионам');
			var header_row = stat_table.createTHead().insertRow();
			header_row.insertCell().innerHTML = 'Регион';
			header_row.insertCell().innerHTML = 'Количество комментариев';
			var stat = JSON.parse(this.responseText);
			for (var i in stat){
				var row = stat_table.insertRow()
				row.insertCell().innerHTML = '<a href="#" onclick="get_city_stat('+stat[i].region_id+'); return false;">'+ 
				stat[i].region_name+'</a>';
				row.insertCell().innerHTML = stat[i].cnt;
			}
		} else {
				alert('Произошла ошибка при загрузке списка регионов');
		}
	});
	request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
	request.send('action=get_region_stat');
});

//количество комментариев по городам
function get_city_stat(region_id){
	var stat_table = document.getElementById('stat_table');
	var request = new XMLHttpRequest();
	request.open('POST', '/stat/');
	request.addEventListener('readystatechange', function(){
		if (this.readyState != 4){
			return;
		}
		
		if (this.status === 200) {
			stat_table.innerHTML = '';
			var stat_list = JSON.parse(this.responseText);
			var header_row = stat_table.createTHead().insertRow();
			header_row.insertCell().innerHTML = 'Город';
			header_row.insertCell().innerHTML = 'Количество комментариев';
			var stat = JSON.parse(this.responseText);
			for (var i in stat){
				var row = stat_table.insertRow()
				row.insertCell().innerHTML = stat[i].city_name;
				row.insertCell().innerHTML = stat[i].cnt;
			}
		} else {
				alert('Произошла ошибка при загрузке списка городов');
		}
	});
	request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
	request.send('action=get_city_stat&region_id='+region_id);
}